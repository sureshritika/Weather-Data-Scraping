import sys
import os
from pathlib import Path
import xml.dom.minidom
import mysql.connector
from datetime import datetime , timedelta
import socket

for file in os.listdir():
	if file.endswith(".xhtml"):
		os.remove(Path(file).stem+".html")
		try:
			conn = mysql.connector.connect(host="localhost" , user="root" , password="" , database="njweather")
			cur = conn.cursor()
			
			doc = xml.dom.minidom.parse(file)
			tag = doc.getElementsByTagName("div")
			
			for elem in tag:
				if elem.getAttribute("id") == "current-conditions-body":
					for div in elem.childNodes:
						if div.nodeType == div.ELEMENT_NODE:
							if div.getAttribute("id") == "current_conditions_detail":
								tab = div.getElementsByTagName('table')
								for tr in tab[0].getElementsByTagName('tr'):
									for b in tr.getElementsByTagName('b'):
										for item in b.childNodes:
											if item.nodeValue == "Last update":
												d_or_t = tr.childNodes[1].firstChild.nodeValue.strip().split()
								date = d_or_t[0] + " " + d_or_t[1] + " " + str(datetime.now().year)
								date = datetime.strptime(date , "%d %b %Y").strftime("%a %d %b %Y")
								time = d_or_t[2] + " " + d_or_t[3] + " " + d_or_t[4]
								#print("date: " + date)
								#print("time: " + time)
			for elem in tag:
				if elem.getAttribute("id") == "seven-day-forecast":
					for div in elem.childNodes:
						if div.nodeType == div.ELEMENT_NODE:
							if div.getAttribute("class") == "panel-heading":
								for pan in div.childNodes:
									if pan.nodeType == pan.ELEMENT_NODE:
										if pan.getAttribute("class") == "panel-title":
											city = pan.childNodes[0].nodeValue.strip().split()[0]
											cur.execute("DROP TABLE {tab}".format(tab=city))
											cur.execute("CREATE TABLE {tab} (id INT AUTO_INCREMENT PRIMARY KEY , d_or_n VARCHAR(255) , week VARCHAR(255) , date VARCHAR(255) , time VARCHAR(255) , temp VARCHAR(255) , short_des VARCHAR(255) , long_des VARCHAR(500) , img VARCHAR(500))".format(tab=city))			
							if div.getAttribute("class") == "panel-body":
								for pan in div.childNodes:
									if pan.nodeType == pan.ELEMENT_NODE:
										if pan.getAttribute("id") == "seven-day-forecast-container":
											for sev in pan.childNodes:
												if pan.getAttribute("id") == "seven-day-forecast-container":
													for sev in pan.childNodes:
														for lis in sev.childNodes:
															if lis.getAttribute("class") == "forecast-tombstone":
																item = lis.childNodes.item(1)
																week = ""
																for tan in item.childNodes.item(1).childNodes:
																	if tan.nodeType == tan.TEXT_NODE:
																		week += tan.nodeValue + " "
																#print(week)
																if "night" not in week.lower():
																	d_or_n = "Day"
																else:
																	d_or_n = "Night"
																#print(d_or_n)
																img = "https://forecast.weather.gov/"+item.childNodes.item(3).childNodes.item(0).getAttribute("src")
																#print(img)
																long_des = item.childNodes.item(3).childNodes.item(0).getAttribute("title").split(": " , 1)[1]
																#print(long_des)
																short_des = ""
																for tan in item.childNodes.item(4).childNodes:
																	if tan.nodeType == tan.TEXT_NODE:
																		short_des += tan.nodeValue + " "
																#print(short_des)
																temp = "".join(filter(str.isdigit , item.childNodes.item(5).childNodes.item(0).nodeValue))
																#print(temp)
																cur.execute("INSERT INTO {tab} (d_or_n , week , date , time , temp , short_des , long_des , img) VALUES (%s , %s , %s , %s , %s , %s , %s , %s)".format(tab=city) , (d_or_n , week , date , time , temp , short_des , long_des , img))
																conn.commit()
			
			cur.execute("SELECT * FROM {tab}".format(tab=city))
			res = cur.fetchall()
			new_date = datetime.strptime(res[0][3] , "%a %d %b %Y")
			for i in range(len(res)-1):
				if "night" in res[i][2].lower():
					new_date += timedelta(days=1)
				cur.execute("UPDATE {tab} SET date = %s WHERE id = %s".format(tab=city) , (new_date.strftime("%a %d %b %Y") , i+2))
				conn.commit()
			
			print("--------------city: "+city)
			cur.execute("SELECT * FROM {tab}".format(tab=city))
			res = cur.fetchall()
			for i in range(len(res)):	
				print(res[i])
			
			cur.close()
		except mysql.connector.Error as err:
			print(err)
		finally:
			try:
				conn
			except NameError:
				pass
			else:
				conn.close()
		os.remove(file)
