#!/bin/sh

while true
do
	wget -O newark.html -q "https://forecast.weather.gov/MapClick.php?CityName=Newark&state=NJ"
	java -jar tagsoup-1.2.1.jar --files newark.html

	wget -O trenton.html -q "https://forecast.weather.gov/MapClick.php?CityName=Trenton&state=NJ"
	java -jar tagsoup-1.2.1.jar --files trenton.html

	wget -O princeton.html -q "https://forecast.weather.gov/MapClick.php?CityName=Princeton&state=NJ"
	java -jar tagsoup-1.2.1.jar --files princeton.html

	wget -O hoboken.html -q "https://forecast.weather.gov/MapClick.php?CityName=Hoboken&state=NJ"
	java -jar tagsoup-1.2.1.jar --files hoboken.html

	wget -O hackensack.html -q "https://forecast.weather.gov/MapClick.php?CityName=Hackensack&state=NJ"
	java -jar tagsoup-1.2.1.jar --files hackensack.html
	
	python3 parser.py
	
	sleep 6h
done
