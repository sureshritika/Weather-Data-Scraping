<?php require_once('nav.php'); ?>
<html>
	<?php
		$conn = new mysqli("localhost" , "root" , "" , "njweather");
		
		if ($conn->connect_error)
			die("connection failed: " . $conn->connect_error);
		
		$ip = getHostByName(getHostName());
		$sql = "INSERT INTO dashboard (ip , city) SELECT * FROM (SELECT '$ip' AS ip , 'Newark' AS city) AS temp WHERE NOT EXISTS (SELECT ip FROM dashboard WHERE ip = '$ip') LIMIT 1";
		$conn->query($sql);
		
		$sql = "SELECT ip , city FROM dashboard WHERE ip = '$ip'";
		if ($result = $conn->query($sql)) {
		  while ($row = $result->fetch_row()) {
			$city = $row[1];
		  }
		}
		
		if(ISSET($_POST["update"])){
			$city = $_POST["dash_pref_radio"];
			$sql = "UPDATE dashboard SET city='$city' WHERE ip='$ip'";
			if ($conn->query($sql) === TRUE)
				echo "update successful";
			else
				echo "update error: " . $conn->error;
			header("location: njweather.php");
		}
	?>
    <head>
        <title>Dashboard</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>		
		<div>
			<div style="display:flex; align-items:center; justify-content:space-between;">
				<h1><b>Dashboard</b></h1>
				<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#staticBackdrop">
				  <span class="glyphicon glyphicon-pencil"></span>  Customize dashboard
				</button>
			</div>
			<div class="modal" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" action="">
					<div class="modal-header">
						<h3 class="modal-title">Customize dashboard</h3>
					</div>
					<div class="modal-body">
						<div class="form-check">
							<input class="form-check-input" type="radio" name="dash_pref_radio" id="Newark" value="Newark" <?php echo ($city=="Newark")?"checked":"" ?>>
							<label class="form-check-label" for="Newark">Newark</label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="dash_pref_radio" id="Trenton" value="Trenton" <?php echo ($city=="Trenton")?"checked":"" ?>>
							<label class="form-check-label" for="Trenton">Trenton</label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="dash_pref_radio" id="Princeton" value="Princeton" <?php echo ($city=="Princeton")?"checked":"" ?>>
							<label class="form-check-label" for="Princeton">Princeton</label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="dash_pref_radio" id="Hoboken" value="Hoboken" <?php echo ($city=="Hoboken")?"checked":"" ?>>
							<label class="form-check-label" for="Hoboken">Hoboken</label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="dash_pref_radio" id="Hackensack" value="Hackensack" <?php echo ($city=="Hackensack")?"checked":"" ?>>
							<label class="form-check-label" for="Hackensack">Hackensack</label>
						</div>
					</div>
					<div style="clear:both;"></div>
						<div class="modal-footer">
							<button class="btn btn-danger" name="close" type="reset"><span class="glyphicon glyphicon-remove"></span> Close</button>
							<button class="btn btn-warning" name="update"><span class="glyphicon glyphicon-edit"></span> Update</button>
						</div>
					</div>
				</form>
			</div>
			</div>
			</div>
			<script>
				$(function () {
					$(".modal-footer").click(function () {
						$(".modal").modal("hide");
					});
				});
			</script>
		</div>
		
		<div>
			<h2><b><?php echo "$city, NJ"; ?></b></h2>
			<table width=100% style="border-collapse:separate; border-spacing: 0 30px;">
			<?php
				$sql = "SELECT date , COUNT(*) AS count FROM $city GROUP BY date";
				$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{
						$date = $row["date"];
						
						$sql2 = "SELECT * FROM $city WHERE date = '$date'";
						$result2 = $conn->query($sql2);
						$count = $result2->num_rows;
						
						$row2 = $result2->fetch_all(MYSQLI_ASSOC);
						echo "<tr style='width:100%'>";
						for ($i = 0 ; $i < $count ; $i ++)
						{
							if ($count === 1 and $row2[$i]["d_or_n"] === "Night")
								echo "<td></td>";
							echo "<td style='width:50%; vertical-align:top; position:relative; left:4px;'> ";
								echo "<div><b>".substr($row2[$i]["date"] , 0 , 6)."</b>"." | ".$row2[$i]["d_or_n"]."<br></div>";
								echo "<div>".$row2[$i]["short_des"]."<br></div>";
								echo "<div><font size='6' style='vertical-align:middle;'>".$row2[$i]["temp"]."&deg</font>";
								echo "<img src=".$row2[$i]["img"].">"."<br></div>";
								echo "<div>".$row2[$i]["long_des"]."<br></div>";
							echo "</td>";
						}
						echo "</tr>";
					}
			?>
			</table>
		</div>
    </body>
   	<?php
    	$conn->close();
    ?>
</html>
