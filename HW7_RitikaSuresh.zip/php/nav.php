<html>
<head>
<style>
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: #333;
}

li {
	float: left;
}

li a {
	display: block;
	color: white;
	text-align: center;
	font-size:15px;
	padding: 10px 12px;
	text-decoration: none;
}

li a:hover {
	background-color: #111;
	text-decoration: none;
}

</style>
</head>
<body>

<ul>
	<li><a href="njweather.php">Dashboard</a></li>
	<li><a href="newark.php">Newark</a></li>
	<li><a href="trenton.php">Trenton</a></li>
	<li><a href="princeton.php">Princeton</a></li>
	<li><a href="hoboken.php">Hoboken</a></li>
	<li><a href="hackensack.php">Hackensack</a></li>
</ul>

</body>
</html>
