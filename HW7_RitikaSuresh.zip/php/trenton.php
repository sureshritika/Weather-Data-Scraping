<?php require_once('nav.php'); ?>
<html>
	<?php
		$conn = new mysqli("localhost" , "root" , "" , "njweather");
		
		if ($conn->connect_error)
			die("connection failed: " . $conn->connect_error);

		$city = "Trenton";
	?>
    
    <head>
        <title>Dashboard</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>	
		<div>
			<h2><b><?php echo "$city, NJ"; ?></b></h2>
			<table width=100% style="border-collapse:separate; border-spacing: 0 30px;">
			<?php
				$sql = "SELECT date , COUNT(*) AS count FROM $city GROUP BY date";
				$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{
						$date = $row["date"];
						
						$sql2 = "SELECT * FROM $city WHERE date = '$date'";
						$result2 = $conn->query($sql2);
						$count = $result2->num_rows;
						
						$row2 = $result2->fetch_all(MYSQLI_ASSOC);
						echo "<tr style='width:100%'>";
						for ($i = 0 ; $i < $count ; $i ++)
						{
							if ($count === 1 and $row2[$i]["d_or_n"] === "Night")
								echo "<td></td>";
							echo "<td style='width:50%; vertical-align:top; position:relative; left:4px;'> ";
								echo "<div><b>".substr($row2[$i]["date"] , 0 , 6)."</b>"." | ".$row2[$i]["d_or_n"]."<br></div>";
								echo "<div>".$row2[$i]["short_des"]."<br></div>";
								echo "<div><font size='6' style='vertical-align:middle;'>".$row2[$i]["temp"]."&deg</font>";
								echo "<img src=".$row2[$i]["img"].">"."<br></div>";
								echo "<div>".$row2[$i]["long_des"]."<br></div>";
							echo "</td>";
						}
						echo "</tr>";
					}
			?>
			</table>
		</div>
	</body>
   	<?php
    	$conn->close();
    ?>
</html>
